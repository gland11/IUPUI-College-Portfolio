﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Group_Project
{
    public partial class Answers : Form
    {
        public Answers()
        {
            InitializeComponent();
        }

        private void AnswersClose_Button_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
