﻿namespace Group_Project
{
    partial class Answers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AnswersClose_Button = new System.Windows.Forms.Button();
            this.Answers_listBox = new System.Windows.Forms.ListBox();
            this.label1 = new System.Windows.Forms.Label();
            this.answer1 = new System.Windows.Forms.Label();
            this.answer2 = new System.Windows.Forms.Label();
            this.answer3 = new System.Windows.Forms.Label();
            this.answer4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.check1 = new System.Windows.Forms.Label();
            this.check2 = new System.Windows.Forms.Label();
            this.check3 = new System.Windows.Forms.Label();
            this.check4 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // AnswersClose_Button
            // 
            this.AnswersClose_Button.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.AnswersClose_Button.Location = new System.Drawing.Point(412, 645);
            this.AnswersClose_Button.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.AnswersClose_Button.Name = "AnswersClose_Button";
            this.AnswersClose_Button.Size = new System.Drawing.Size(180, 56);
            this.AnswersClose_Button.TabIndex = 51;
            this.AnswersClose_Button.Text = "Close";
            this.AnswersClose_Button.UseVisualStyleBackColor = true;
            this.AnswersClose_Button.Click += new System.EventHandler(this.AnswersClose_Button_Click);
            // 
            // Answers_listBox
            // 
            this.Answers_listBox.FormattingEnabled = true;
            this.Answers_listBox.ItemHeight = 31;
            this.Answers_listBox.Location = new System.Drawing.Point(24, 203);
            this.Answers_listBox.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Answers_listBox.Name = "Answers_listBox";
            this.Answers_listBox.Size = new System.Drawing.Size(564, 345);
            this.Answers_listBox.TabIndex = 50;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(624, 149);
            this.label1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(175, 32);
            this.label1.TabIndex = 52;
            this.label1.Text = "User Answer";
            // 
            // answer1
            // 
            this.answer1.AutoSize = true;
            this.answer1.Location = new System.Drawing.Point(636, 207);
            this.answer1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.answer1.Name = "answer1";
            this.answer1.Size = new System.Drawing.Size(0, 32);
            this.answer1.TabIndex = 53;
            // 
            // answer2
            // 
            this.answer2.AutoSize = true;
            this.answer2.Location = new System.Drawing.Point(636, 294);
            this.answer2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.answer2.Name = "answer2";
            this.answer2.Size = new System.Drawing.Size(0, 32);
            this.answer2.TabIndex = 54;
            // 
            // answer3
            // 
            this.answer3.AutoSize = true;
            this.answer3.Location = new System.Drawing.Point(636, 389);
            this.answer3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.answer3.Name = "answer3";
            this.answer3.Size = new System.Drawing.Size(0, 32);
            this.answer3.TabIndex = 55;
            // 
            // answer4
            // 
            this.answer4.AutoSize = true;
            this.answer4.Location = new System.Drawing.Point(636, 473);
            this.answer4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.answer4.Name = "answer4";
            this.answer4.Size = new System.Drawing.Size(0, 32);
            this.answer4.TabIndex = 56;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(186, 149);
            this.label2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(346, 32);
            this.label2.TabIndex = 57;
            this.label2.Text = "Correct Answer in List Box";
            // 
            // check1
            // 
            this.check1.AutoSize = true;
            this.check1.Location = new System.Drawing.Point(872, 207);
            this.check1.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.check1.Name = "check1";
            this.check1.Size = new System.Drawing.Size(0, 32);
            this.check1.TabIndex = 58;
            // 
            // check2
            // 
            this.check2.AutoSize = true;
            this.check2.Location = new System.Drawing.Point(872, 294);
            this.check2.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.check2.Name = "check2";
            this.check2.Size = new System.Drawing.Size(0, 32);
            this.check2.TabIndex = 59;
            // 
            // check3
            // 
            this.check3.AutoSize = true;
            this.check3.Location = new System.Drawing.Point(872, 389);
            this.check3.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.check3.Name = "check3";
            this.check3.Size = new System.Drawing.Size(0, 32);
            this.check3.TabIndex = 60;
            // 
            // check4
            // 
            this.check4.AutoSize = true;
            this.check4.Location = new System.Drawing.Point(872, 473);
            this.check4.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.check4.Name = "check4";
            this.check4.Size = new System.Drawing.Size(0, 32);
            this.check4.TabIndex = 61;
            // 
            // Answers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(16F, 31F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.AnswersClose_Button;
            this.ClientSize = new System.Drawing.Size(1050, 897);
            this.Controls.Add(this.check4);
            this.Controls.Add(this.check3);
            this.Controls.Add(this.check2);
            this.Controls.Add(this.check1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.answer4);
            this.Controls.Add(this.answer3);
            this.Controls.Add(this.answer2);
            this.Controls.Add(this.answer1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.AnswersClose_Button);
            this.Controls.Add(this.Answers_listBox);
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "Answers";
            this.Text = "Answers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button AnswersClose_Button;
        internal System.Windows.Forms.ListBox Answers_listBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        internal System.Windows.Forms.Label answer1;
        internal System.Windows.Forms.Label answer2;
        internal System.Windows.Forms.Label answer3;
        internal System.Windows.Forms.Label answer4;
        internal System.Windows.Forms.Label check1;
        internal System.Windows.Forms.Label check2;
        internal System.Windows.Forms.Label check3;
        internal System.Windows.Forms.Label check4;
    }
}