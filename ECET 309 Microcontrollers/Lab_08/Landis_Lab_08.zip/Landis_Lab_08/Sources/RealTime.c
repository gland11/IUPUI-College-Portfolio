/*************************************************************
 *                                                           *
 * Name: George Landis                                       *
 * Title of Program: Lab 08 T-Bird Turn Signal               *
 *                                                           *
 * Class:ECET 30903                                          *
 * Due Date:3/04/19                                          *
 * Description:                                              *
 *                                                           *
 *                                                           *
 *************************************************************/
