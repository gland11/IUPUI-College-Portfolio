void Delay(unsigned long int);
void InitializeLCD(void);
void Display(unsigned char*);
void LCDInit(unsigned char);
void LCDData(unsigned char);
void BusyCheck(void);
void CallingFunction(void);

void Stuff(unsigned char);

void DoMath(unsigned char);