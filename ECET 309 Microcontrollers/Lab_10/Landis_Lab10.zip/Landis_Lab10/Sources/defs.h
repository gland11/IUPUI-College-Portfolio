#define HOME_DISPLAY    PORTK = 0x02
#define CLEAR_DISPLAY   PORTK = 0x01
#define SECOND_LINE     PORTK = 0xC0

#define DISPLAY_OFF     (PORTE = 0x00)
#define DISPLAY_RED     (PORTE = 0x04)
#define DISPLAY_GREEN   (PORTE = 0x08)
#define DISPLAY_BLUE    (PORTE = 0x0C)
