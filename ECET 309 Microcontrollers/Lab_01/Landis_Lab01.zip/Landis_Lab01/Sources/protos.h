//This is protos.h for Lab_01 ECET 30903
#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */
/*************************************************************
 *                                                           *
 * Name: George Landis                                       *
 * Title of Program: Lab 01 Simple Factorial Program         *
 * Date:1/8/19                                               *
 * Class:ECET 30903                                          *
 * Due Date:1//19                                            *
 * Description:                                              *
 *                                                           *
 *                                                           *
 *************************************************************/
 
 // Function Prototypes Go Here
 void FillTable(void);
 int Fact(int num);