
/*************************************************************
 *                                                           *
 * Name: George Landis                                       *
 * Title of Program: Lab 04 I/O Using Logic Operations,      * 
 *                          Bit Fields LEDs & Switches       *
 * Date:2/2/19                                               *
 * Class:ECET 30903                                          *
 * Due Date:2/05/19                                          *
 * Description:                                              *
 *                                                           *
 *                                                           *
 *************************************************************/

//This is the protos.h file to hold the prototype definitions
//void TradFuntion(void);
void ModernFuntion(void);