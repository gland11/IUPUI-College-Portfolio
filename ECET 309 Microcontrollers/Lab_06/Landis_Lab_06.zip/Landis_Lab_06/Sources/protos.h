void Delay(unsigned long int delayVal);
void InitializeLCD(void);
void Display(unsigned char* message);
void LCDInit(unsigned char dataVal);
void LCDData(unsigned char stringVal);