#include <hidef.h>      /* common defines and macros */
#include "derivative.h"      /* derivative-specific definitions */

 volatile unsigned char AsciiFuncition(unsigned char valPass)
 volatile unsigned char NumFunction(unsigned char valPass)
/*************************************************************
 *                                                           *
 * Name: George Landis                                       *
 * Title of Program: Lab 02 4x4 Matrix Keypad                * 
 *                                       & Parallel Arrays   *
 * Date:1/17/19                                              *
 * Class:ECET 30903                                          *
 * Due Date:1/21/19                                          *
 * Description:                                              *
 *                                                           *
 *                                                           *
 *************************************************************
 */
// Global Variables Go Down here
