/*************************************************************
 *                                                           *
 * Name: George Landis                                       *
 * Title of Program: Lab 05 Hardware Abstraction Layer: I/O  * 
 *                          Using MacrosLEDs and Switches    *
 * Date:2/2/19                                               *
 * Class:ECET 30903                                          *
 * Due Date:2/05/19                                          *
 * Description:                                              *
 *                                                           *
 *                                                           *
 *************************************************************/
 //This is the protos.h file to hold the prototype definitions
void TradFuntion(void);