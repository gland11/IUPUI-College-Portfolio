﻿namespace Lab10_11
{
    partial class Vending_machine
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Vending_machine));
            this.panel1 = new System.Windows.Forms.Panel();
            this.kitkatcount = new System.Windows.Forms.Label();
            this.kitkatleft = new System.Windows.Forms.Label();
            this.kitkatprice = new System.Windows.Forms.Label();
            this.kitkatPicturebox = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.mmamount = new System.Windows.Forms.Label();
            this.mmleft = new System.Windows.Forms.Label();
            this.mmprice = new System.Windows.Forms.Label();
            this.mmPicturebox = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.reesesamount = new System.Windows.Forms.Label();
            this.reesesleft = new System.Windows.Forms.Label();
            this.reesesprice = new System.Windows.Forms.Label();
            this.reesesPicturebox = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.skittlesamount = new System.Windows.Forms.Label();
            this.skittlesleft = new System.Windows.Forms.Label();
            this.skittlesprice = new System.Windows.Forms.Label();
            this.skittlesPicturebox = new System.Windows.Forms.PictureBox();
            this.panel5 = new System.Windows.Forms.Panel();
            this.snickersamount = new System.Windows.Forms.Label();
            this.snickersleft = new System.Windows.Forms.Label();
            this.snickersprice = new System.Windows.Forms.Label();
            this.snickersPicturebox = new System.Windows.Forms.PictureBox();
            this.exitbutton = new System.Windows.Forms.Button();
            this.totalsales = new System.Windows.Forms.Label();
            this.selectACandyLabel = new System.Windows.Forms.Label();
            this.microBitcoinLabel = new System.Windows.Forms.Label();
            this.totalSalesLabel = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kitkatPicturebox)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmPicturebox)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reesesPicturebox)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skittlesPicturebox)).BeginInit();
            this.panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.snickersPicturebox)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.kitkatcount);
            this.panel1.Controls.Add(this.kitkatleft);
            this.panel1.Controls.Add(this.kitkatprice);
            this.panel1.Controls.Add(this.kitkatPicturebox);
            this.panel1.Location = new System.Drawing.Point(32, 89);
            this.panel1.Margin = new System.Windows.Forms.Padding(2);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(220, 117);
            this.panel1.TabIndex = 1;
            // 
            // kitkatcount
            // 
            this.kitkatcount.AutoSize = true;
            this.kitkatcount.Location = new System.Drawing.Point(135, 96);
            this.kitkatcount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.kitkatcount.Name = "kitkatcount";
            this.kitkatcount.Size = new System.Drawing.Size(24, 17);
            this.kitkatcount.TabIndex = 4;
            this.kitkatcount.Text = "20";
            // 
            // kitkatleft
            // 
            this.kitkatleft.AutoSize = true;
            this.kitkatleft.Location = new System.Drawing.Point(132, 60);
            this.kitkatleft.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.kitkatleft.Name = "kitkatleft";
            this.kitkatleft.Size = new System.Drawing.Size(66, 17);
            this.kitkatleft.TabIndex = 3;
            this.kitkatleft.Text = "Item Left:";
            // 
            // kitkatprice
            // 
            this.kitkatprice.AutoSize = true;
            this.kitkatprice.Location = new System.Drawing.Point(131, 29);
            this.kitkatprice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.kitkatprice.Name = "kitkatprice";
            this.kitkatprice.Size = new System.Drawing.Size(54, 17);
            this.kitkatprice.TabIndex = 2;
            this.kitkatprice.Text = "μ₿ 580";
            // 
            // kitkatPicturebox
            // 
            this.kitkatPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("kitkatPicturebox.Image")));
            this.kitkatPicturebox.Location = new System.Drawing.Point(2, 2);
            this.kitkatPicturebox.Margin = new System.Windows.Forms.Padding(2);
            this.kitkatPicturebox.Name = "kitkatPicturebox";
            this.kitkatPicturebox.Size = new System.Drawing.Size(102, 111);
            this.kitkatPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.kitkatPicturebox.TabIndex = 0;
            this.kitkatPicturebox.TabStop = false;
            this.kitkatPicturebox.Click += new System.EventHandler(this.kitkatPicturebox_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.mmamount);
            this.panel2.Controls.Add(this.mmleft);
            this.panel2.Controls.Add(this.mmprice);
            this.panel2.Controls.Add(this.mmPicturebox);
            this.panel2.Location = new System.Drawing.Point(32, 327);
            this.panel2.Margin = new System.Windows.Forms.Padding(2);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(220, 127);
            this.panel2.TabIndex = 16;
            // 
            // mmamount
            // 
            this.mmamount.AutoSize = true;
            this.mmamount.Location = new System.Drawing.Point(138, 99);
            this.mmamount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mmamount.Name = "mmamount";
            this.mmamount.Size = new System.Drawing.Size(24, 17);
            this.mmamount.TabIndex = 19;
            this.mmamount.Text = "20";
            // 
            // mmleft
            // 
            this.mmleft.AutoSize = true;
            this.mmleft.Location = new System.Drawing.Point(137, 57);
            this.mmleft.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mmleft.Name = "mmleft";
            this.mmleft.Size = new System.Drawing.Size(66, 17);
            this.mmleft.TabIndex = 18;
            this.mmleft.Text = "Item Left:";
            // 
            // mmprice
            // 
            this.mmprice.AutoSize = true;
            this.mmprice.Location = new System.Drawing.Point(130, 13);
            this.mmprice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.mmprice.Name = "mmprice";
            this.mmprice.Size = new System.Drawing.Size(54, 17);
            this.mmprice.TabIndex = 17;
            this.mmprice.Text = "μ₿ 750";
            // 
            // mmPicturebox
            // 
            this.mmPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("mmPicturebox.Image")));
            this.mmPicturebox.Location = new System.Drawing.Point(2, 4);
            this.mmPicturebox.Margin = new System.Windows.Forms.Padding(2);
            this.mmPicturebox.Name = "mmPicturebox";
            this.mmPicturebox.Size = new System.Drawing.Size(102, 121);
            this.mmPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.mmPicturebox.TabIndex = 0;
            this.mmPicturebox.TabStop = false;
            this.mmPicturebox.Click += new System.EventHandler(this.mmPicturebox_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.reesesamount);
            this.panel3.Controls.Add(this.reesesleft);
            this.panel3.Controls.Add(this.reesesprice);
            this.panel3.Controls.Add(this.reesesPicturebox);
            this.panel3.Location = new System.Drawing.Point(32, 209);
            this.panel3.Margin = new System.Windows.Forms.Padding(2);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(220, 115);
            this.panel3.TabIndex = 2;
            // 
            // reesesamount
            // 
            this.reesesamount.AutoSize = true;
            this.reesesamount.Location = new System.Drawing.Point(136, 95);
            this.reesesamount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.reesesamount.Name = "reesesamount";
            this.reesesamount.Size = new System.Drawing.Size(24, 17);
            this.reesesamount.TabIndex = 11;
            this.reesesamount.Text = "20";
            // 
            // reesesleft
            // 
            this.reesesleft.AutoSize = true;
            this.reesesleft.Location = new System.Drawing.Point(130, 60);
            this.reesesleft.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.reesesleft.Name = "reesesleft";
            this.reesesleft.Size = new System.Drawing.Size(66, 17);
            this.reesesleft.TabIndex = 10;
            this.reesesleft.Text = "Item Left:";
            // 
            // reesesprice
            // 
            this.reesesprice.AutoSize = true;
            this.reesesprice.Location = new System.Drawing.Point(128, 25);
            this.reesesprice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.reesesprice.Name = "reesesprice";
            this.reesesprice.Size = new System.Drawing.Size(54, 17);
            this.reesesprice.TabIndex = 9;
            this.reesesprice.Text = "μ₿ 580";
            // 
            // reesesPicturebox
            // 
            this.reesesPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("reesesPicturebox.Image")));
            this.reesesPicturebox.Location = new System.Drawing.Point(2, 2);
            this.reesesPicturebox.Margin = new System.Windows.Forms.Padding(2);
            this.reesesPicturebox.Name = "reesesPicturebox";
            this.reesesPicturebox.Size = new System.Drawing.Size(102, 109);
            this.reesesPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.reesesPicturebox.TabIndex = 0;
            this.reesesPicturebox.TabStop = false;
            this.reesesPicturebox.Click += new System.EventHandler(this.reesesPicturebox_Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.skittlesamount);
            this.panel4.Controls.Add(this.skittlesleft);
            this.panel4.Controls.Add(this.skittlesprice);
            this.panel4.Controls.Add(this.skittlesPicturebox);
            this.panel4.Location = new System.Drawing.Point(256, 89);
            this.panel4.Margin = new System.Windows.Forms.Padding(2);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(220, 117);
            this.panel4.TabIndex = 5;
            // 
            // skittlesamount
            // 
            this.skittlesamount.AutoSize = true;
            this.skittlesamount.Location = new System.Drawing.Point(141, 96);
            this.skittlesamount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.skittlesamount.Name = "skittlesamount";
            this.skittlesamount.Size = new System.Drawing.Size(24, 17);
            this.skittlesamount.TabIndex = 8;
            this.skittlesamount.Text = "20";
            // 
            // skittlesleft
            // 
            this.skittlesleft.AutoSize = true;
            this.skittlesleft.Location = new System.Drawing.Point(139, 69);
            this.skittlesleft.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.skittlesleft.Name = "skittlesleft";
            this.skittlesleft.Size = new System.Drawing.Size(66, 17);
            this.skittlesleft.TabIndex = 7;
            this.skittlesleft.Text = "Item Left:";
            // 
            // skittlesprice
            // 
            this.skittlesprice.AutoSize = true;
            this.skittlesprice.Location = new System.Drawing.Point(138, 34);
            this.skittlesprice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.skittlesprice.Name = "skittlesprice";
            this.skittlesprice.Size = new System.Drawing.Size(54, 17);
            this.skittlesprice.TabIndex = 6;
            this.skittlesprice.Text = "μ₿ 460";
            // 
            // skittlesPicturebox
            // 
            this.skittlesPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("skittlesPicturebox.Image")));
            this.skittlesPicturebox.Location = new System.Drawing.Point(2, 2);
            this.skittlesPicturebox.Margin = new System.Windows.Forms.Padding(2);
            this.skittlesPicturebox.Name = "skittlesPicturebox";
            this.skittlesPicturebox.Size = new System.Drawing.Size(96, 111);
            this.skittlesPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.skittlesPicturebox.TabIndex = 0;
            this.skittlesPicturebox.TabStop = false;
            this.skittlesPicturebox.Click += new System.EventHandler(this.skittlesPicturebox_Click);
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.snickersamount);
            this.panel5.Controls.Add(this.snickersleft);
            this.panel5.Controls.Add(this.snickersprice);
            this.panel5.Controls.Add(this.snickersPicturebox);
            this.panel5.Location = new System.Drawing.Point(256, 209);
            this.panel5.Margin = new System.Windows.Forms.Padding(2);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(220, 115);
            this.panel5.TabIndex = 12;
            // 
            // snickersamount
            // 
            this.snickersamount.AutoSize = true;
            this.snickersamount.Location = new System.Drawing.Point(134, 94);
            this.snickersamount.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.snickersamount.Name = "snickersamount";
            this.snickersamount.Size = new System.Drawing.Size(24, 17);
            this.snickersamount.TabIndex = 15;
            this.snickersamount.Text = "20";
            // 
            // snickersleft
            // 
            this.snickersleft.AutoSize = true;
            this.snickersleft.Location = new System.Drawing.Point(130, 57);
            this.snickersleft.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.snickersleft.Name = "snickersleft";
            this.snickersleft.Size = new System.Drawing.Size(66, 17);
            this.snickersleft.TabIndex = 14;
            this.snickersleft.Text = "Item Left:";
            // 
            // snickersprice
            // 
            this.snickersprice.AutoSize = true;
            this.snickersprice.Location = new System.Drawing.Point(132, 19);
            this.snickersprice.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.snickersprice.Name = "snickersprice";
            this.snickersprice.Size = new System.Drawing.Size(54, 17);
            this.snickersprice.TabIndex = 13;
            this.snickersprice.Text = "μ₿ 160";
            // 
            // snickersPicturebox
            // 
            this.snickersPicturebox.Image = ((System.Drawing.Image)(resources.GetObject("snickersPicturebox.Image")));
            this.snickersPicturebox.Location = new System.Drawing.Point(2, 2);
            this.snickersPicturebox.Margin = new System.Windows.Forms.Padding(2);
            this.snickersPicturebox.Name = "snickersPicturebox";
            this.snickersPicturebox.Size = new System.Drawing.Size(96, 110);
            this.snickersPicturebox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.snickersPicturebox.TabIndex = 0;
            this.snickersPicturebox.TabStop = false;
            this.snickersPicturebox.Click += new System.EventHandler(this.snickersPicturebox_Click);
            // 
            // exitbutton
            // 
            this.exitbutton.DialogResult = System.Windows.Forms.DialogResult.Cancel;
            this.exitbutton.Location = new System.Drawing.Point(350, 413);
            this.exitbutton.Margin = new System.Windows.Forms.Padding(2);
            this.exitbutton.Name = "exitbutton";
            this.exitbutton.Size = new System.Drawing.Size(92, 39);
            this.exitbutton.TabIndex = 26;
            this.exitbutton.Text = "Exit";
            this.exitbutton.UseVisualStyleBackColor = true;
            this.exitbutton.Click += new System.EventHandler(this.exitbutton_Click);
            // 
            // totalsales
            // 
            this.totalsales.AutoSize = true;
            this.totalsales.Location = new System.Drawing.Point(347, 374);
            this.totalsales.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.totalsales.Name = "totalsales";
            this.totalsales.Size = new System.Drawing.Size(36, 17);
            this.totalsales.TabIndex = 22;
            this.totalsales.Text = "0.00";
            // 
            // selectACandyLabel
            // 
            this.selectACandyLabel.AutoSize = true;
            this.selectACandyLabel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.selectACandyLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.selectACandyLabel.Location = new System.Drawing.Point(198, 30);
            this.selectACandyLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.selectACandyLabel.Name = "selectACandyLabel";
            this.selectACandyLabel.Size = new System.Drawing.Size(120, 19);
            this.selectACandyLabel.TabIndex = 0;
            this.selectACandyLabel.Text = "Select A Candy";
            this.selectACandyLabel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.selectACandyLabel.Click += new System.EventHandler(this.selectACandyLabel_Click);
            // 
            // microBitcoinLabel
            // 
            this.microBitcoinLabel.AutoSize = true;
            this.microBitcoinLabel.Location = new System.Drawing.Point(317, 374);
            this.microBitcoinLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.microBitcoinLabel.Name = "microBitcoinLabel";
            this.microBitcoinLabel.Size = new System.Drawing.Size(26, 17);
            this.microBitcoinLabel.TabIndex = 21;
            this.microBitcoinLabel.Text = "μ₿";
            // 
            // totalSalesLabel
            // 
            this.totalSalesLabel.AutoSize = true;
            this.totalSalesLabel.Location = new System.Drawing.Point(342, 341);
            this.totalSalesLabel.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.totalSalesLabel.Name = "totalSalesLabel";
            this.totalSalesLabel.Size = new System.Drawing.Size(79, 17);
            this.totalSalesLabel.TabIndex = 20;
            this.totalSalesLabel.Text = "Total Sales";
            this.totalSalesLabel.Click += new System.EventHandler(this.totalSalesLabel_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(94, 489);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(185, 17);
            this.label1.TabIndex = 24;
            this.label1.Text = "150 BTC is equal to $1 USD";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(63, 489);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 17);
            this.label2.TabIndex = 23;
            this.label2.Text = "μ₿";
            // 
            // Vending_machine
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.CancelButton = this.exitbutton;
            this.ClientSize = new System.Drawing.Size(533, 546);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.totalSalesLabel);
            this.Controls.Add(this.microBitcoinLabel);
            this.Controls.Add(this.selectACandyLabel);
            this.Controls.Add(this.totalsales);
            this.Controls.Add(this.exitbutton);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Vending_machine";
            this.Text = "Vending Machine";
            this.Load += new System.EventHandler(this.Vending_machine_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.kitkatPicturebox)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mmPicturebox)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.reesesPicturebox)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.skittlesPicturebox)).EndInit();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.snickersPicturebox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label kitkatcount;
        private System.Windows.Forms.Label kitkatleft;
        private System.Windows.Forms.Label kitkatprice;
        private System.Windows.Forms.PictureBox kitkatPicturebox;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label mmamount;
        private System.Windows.Forms.Label mmleft;
        private System.Windows.Forms.Label mmprice;
        private System.Windows.Forms.PictureBox mmPicturebox;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label reesesamount;
        private System.Windows.Forms.Label reesesleft;
        private System.Windows.Forms.Label reesesprice;
        private System.Windows.Forms.PictureBox reesesPicturebox;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label skittlesamount;
        private System.Windows.Forms.Label skittlesleft;
        private System.Windows.Forms.Label skittlesprice;
        private System.Windows.Forms.PictureBox skittlesPicturebox;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label snickersamount;
        private System.Windows.Forms.Label snickersleft;
        private System.Windows.Forms.Label snickersprice;
        private System.Windows.Forms.PictureBox snickersPicturebox;
        private System.Windows.Forms.Button exitbutton;
        private System.Windows.Forms.Label totalsales;
        private System.Windows.Forms.Label selectACandyLabel;
        private System.Windows.Forms.Label microBitcoinLabel;
        private System.Windows.Forms.Label totalSalesLabel;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}

