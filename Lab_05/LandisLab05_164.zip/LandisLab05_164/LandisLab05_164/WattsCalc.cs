﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//George Landis
// Lab 05
// ECET 164

namespace LandisLab05_164
{
    public partial class WattsCalc : Form
    {
        public WattsCalc()
        {
            InitializeComponent();
        }

        private void calcBtn_Click(object sender, EventArgs e)
        {
            // Local Variables
            double power = 0;
            double seconds; // The Total seconds
            double joules; // the number of joules
            int count = 1; // Loop counter, intialized with 1
            double finalJoules = 0;

            //int kph;    //Kilometers per Hour
           // double mph;     // Miles per hour

            // Display the table of speeds.
            //for (kph = START_SPEED; kph <= END_SPEED; kph += INTERVAL)
            //{
                /// Calculate miles per hour.
             //   mph = kph * CONVERSION_FACTOR;

                ///Display the conversion.
             //   outputListBox.Items.Add(kph + " KPH is the same as " + mph + " MPH");
            //}
           
            // String Balance
            if (double.TryParse(joulesTextBox.Text,out joules))
            {
                
                // Get number of seconds
                if (double.TryParse(secondsTextBox.Text,out seconds))
                {   // Loop calcs the Power of Watts
                    while (count <= seconds)
                    {   // Power equation
                        power = (joules / seconds);
                        // Energy equation
                        finalJoules = (power * seconds);
                        //Add one to the loop counter
                        count = count + 1;
                    }
                    // Display the ending Power
                    powerResultLabel.Text = ("The Power result in Watts is " +  
                        power.ToString("n3")
                        + "W");
                    
                    // Display the Joules in List Box
                    finalResultListBox.Items.Add("Afer " + (count - 1) + " second the work done was " +
                        finalJoules.ToString()
                        + " Joules.");
                        
                    // So I can get it all to work except for the up to 10 and a list part that I do not understand I have gone through
                    // a lot of different areas and tutorials and still am confused. 
                }
                else
                {
                    MessageBox.Show("Invalid value for seconds.");
                }
            }
            else
            {
                // Invalid joules entered
                MessageBox.Show("Invalid value for Joules entered.");
            }
        }

        private void clrBtn_Click(object sender, EventArgs e)
        {
            // Clear all
            joulesTextBox.Text = "";
            secondsTextBox.Text = "";
            powerResultLabel.Text = "";
            finalResultListBox.Items.Clear();
            // Focus Reset.
            joulesTextBox.Focus();
        }

        private void extBtn_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
